
function showNavBar() {

    document.querySelector('nav').classList.toggle('hide');
}